/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ATM_Sederhana;

/**
 *
 * @author dil
 */
public class ATM {

    public static void main(String[] args) {
        int saldo = 1000000; // Saldo awal
        int pilihan;
        java.util.Scanner input = new java.util.Scanner(System.in);

        do {
            // Menampilkan pilihan yang dapat dipilih
            System.out.println("Selamat Datang di ATM Sederhana");
            System.out.println("1. Cek Saldo");
            System.out.println("2. Tarik Tunai");
            System.out.println("3. Setor Tunai");
            System.out.println("4. Keluar");
            System.out.print("Pilih transaksi: ");

            // Mengambil value pilihan
            pilihan = input.nextInt();

            // Penentuan dari pilihan yang dimasukkan
            switch (pilihan) {

                // Cek saldo
                case 1:
                    System.out.println("Saldo Anda saat ini: Rp " + saldo);
                    break;

                // Penarikan saldo 
                case 2:
                    System.out.print("Masukkan jumlah penarikan: Rp ");
                    int tarik = input.nextInt();
                    if (tarik > saldo) {
                        System.out.println("Saldo tidak mencukupi.");
                    } else {
                        saldo -= tarik;
                        System.out.println("Penarikan berhasil. Saldo Anda sekarang: Rp " + saldo);
                    }
                    break;

                // Menambahkan saldo berdasarkan setoran
                case 3:
                    System.out.print("Masukkan jumlah setoran: Rp ");
                    int setor = input.nextInt();
                    saldo += setor;
                    System.out.println("Setoran berhasil. Saldo Anda sekarang: Rp " + saldo);
                    break;

                case 4:
                    System.out.println("Terima kasih telah menggunakan ATM kami.");
                    break;

                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
            System.out.println(); // Breakline agar opsi pilihan terlihat lebih bersih
        } while (pilihan != 4);

        input.close();

    }

}
